package com.capgemini.contactbook.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.capgemini.contactbook.util.ConnectionProvider;
import com.igate.contactbook.bean.EnquiryBean;

public class Client {

	public static void main(String[] args) throws ContactBookException, SQLException {
		int enqryId;
		ContactBookService contactService=new ContactBookServiceImpl();
		EnquiryBean enquiryBean=new EnquiryBean("sdf","hhh","9693866489","Pune","Java");
		enqryId=contactService.addEnquiry(enquiryBean);
		enquiryBean=contactService.getEnquiryDetails(1001);
		System.out.println(enquiryBean);
		}
	}

