package com.capgemini.contactbook.service;

import java.sql.SQLException;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public interface ContactBookService {
public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException;
public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException;
public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException;
}
