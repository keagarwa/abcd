package com.capgemini.contactbook.service;

import java.sql.SQLException;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService {
	ContactBookDao contactDao=new ContactBookDaoImpl();
	private static final Logger logger=Logger.getLogger(ContactBookService.class);

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException {
		try{
		if(isValidEnquiry(enqry))
		return contactDao.addEnquiry(enqry);
		else return 0;
		}catch(SQLException e){
			logger.error(e.getCause()+" "+e.getErrorCode()+" "+e.getMessage());
		}
		return 0;
			}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		return contactDao.getEnquiry(EnquiryID);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		String contactNo=enqry.getContactNo();
		if(!Pattern.matches("[1-9][0-9]{9}",contactNo))
			throw new ContactBookException("Invalid Contact Number");
		String fName=enqry.getfName();
		if(!Pattern.matches("[A-Za-z]{1,50}", fName))
			throw new ContactBookException("Invalid First Name");
		String lName=enqry.getlName();
		if(!Pattern.matches("[A-Za-z]{1,50}", lName))
			throw new ContactBookException("Invalid Last Name");
		String pLocation=enqry.getpLocation();
		if(!Pattern.matches("[A-Za-z]{1,50}",pLocation))
			throw new ContactBookException("Invalid Location Name");
		String domain=enqry.getpDomain();
		if(!Pattern.matches("[A-Za-z]{1,50}", domain))
			throw new ContactBookException("Invalid Domain Name");
		return true;
	}

}
